'use strict';

const fs = require('fs');
const path = require('path');
const { delegateToSubagent } = require('./dispatcher');
const { _writeToPendingQueue } = require('./error-resolver');

async function analyzeCodebase(options = {}) {
  const { context, budget, memory, apiKey, identityDir, templatesDir, dryRun, dataDir, projectRoot } = options;

  const projectFiles = _listProjectFiles(projectRoot || identityDir || '.');

  const task = {
    files: projectFiles,
  };

  let result;
  try {
    result = await delegateToSubagent('codebase-intel', task, {
      context, budget, memory, apiKey, identityDir, templatesDir, dryRun,
    });
  } catch (err) {
    return { action: 'skip', reason: `dispatcher-error: ${err.message}` };
  }

  if (!result || !result.action) {
    result = result || {};
    result.action = 'queue';
  }

  if (dataDir) {
    _writeToPendingQueue(dataDir, {
      type: 'codebase-intel',
      report: result,
    });
  }

  return result;
}

function _listProjectFiles(root, maxFiles = 200) {
  const results = [];
  const ignored = ['node_modules', '.git', '.apppilot', 'dist', 'coverage'];

  function walk(dir, depth) {
    if (depth > 5 || results.length >= maxFiles) return;

    let entries;
    try {
      entries = fs.readdirSync(dir);
    } catch {
      return;
    }

    for (const entry of entries) {
      if (results.length >= maxFiles) break;
      if (ignored.includes(entry) || entry.startsWith('.')) continue;

      const fullPath = path.join(dir, entry);
      try {
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
          walk(fullPath, depth + 1);
        } else if (stat.isFile()) {
          results.push(path.relative(root, fullPath));
        }
      } catch {}
    }
  }

  walk(root, 0);
  return results;
}

module.exports = {
  analyzeCodebase,
  _listProjectFiles,
};
