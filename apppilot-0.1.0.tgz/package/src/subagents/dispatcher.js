'use strict';

const fs = require('fs');
const path = require('path');
const matter = require('gray-matter');
const { buildSystemPrompt } = require('../context-loader');
const { InputSanitizer, OutputValidator } = require('../security');

const MODEL_MAP = {
  haiku: 'claude-haiku-4-5-20251001',
  sonnet: 'claude-sonnet-4-20250514',
  opus: 'claude-opus-4-6',
};

const COST_ESTIMATES = {
  haiku: 0.005,
  sonnet: 0.02,
  opus: 0.10,
};

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function loadSubagentDefinition(agentName, identityDir, templatesDir) {
  const projectPath = path.join(identityDir, 'subagents', `${agentName}.md`);

  try {
    const raw = fs.readFileSync(projectPath, 'utf-8');
    return raw;
  } catch {}

  if (templatesDir) {
    const fallbackPath = path.join(templatesDir, 'subagents', `${agentName}.md`);
    try {
      const raw = fs.readFileSync(fallbackPath, 'utf-8');
      return raw;
    } catch {}
  }

  return `---\nname: ${agentName}\nmodel: sonnet\n---\nYou are the ${agentName} subagent. Analyze the input and return a JSON response.`;
}

function estimateCost(model) {
  return COST_ESTIMATES[model] || COST_ESTIMATES.sonnet;
}

function parseSubagentResponse(response) {
  if (typeof response !== 'string') {
    return { action: 'queue', reason: 'non-string-response', raw: response };
  }

  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      if (!parsed.action) {
        parsed.action = 'queue';
      }
      return parsed;
    }
  } catch {}

  return { action: 'queue', reason: 'parse-failed', raw: response };
}

async function callClaudeAPI(apiKey, systemPrompt, userPrompt, model) {
  const Anthropic = require('@anthropic-ai/sdk');
  const client = new Anthropic({ apiKey });

  const response = await client.messages.create({
    model: MODEL_MAP[model] || MODEL_MAP.sonnet,
    max_tokens: 4096,
    system: systemPrompt,
    messages: [{ role: 'user', content: userPrompt }],
  });

  return response.content[0].text;
}

async function delegateToSubagent(agentName, task, options = {}) {
  const {
    context,
    budget,
    memory,
    apiKey,
    identityDir,
    templatesDir,
    dryRun,
  } = options;

  const definition = loadSubagentDefinition(agentName, identityDir, templatesDir);
  const parsed = matter(definition);
  const model = parsed.data.model || 'sonnet';

  const cost = estimateCost(model);
  if (budget.spent + cost > budget.max) {
    return { action: 'skip', reason: 'budget-exceeded' };
  }

  const systemPrompt = buildSystemPrompt(context) + '\n\n---\n\n' + parsed.content.trim();

  const sanitizedTask = InputSanitizer.wrapAsData('task-data', typeof task === 'string' ? task : JSON.stringify(task, null, 2));

  if (dryRun) {
    return {
      action: 'dry-run',
      subagent: agentName,
      model,
      estimatedCost: cost,
    };
  }

  if (!apiKey) {
    return { action: 'skip', reason: 'no-api-key' };
  }

  let response;
  try {
    response = await callClaudeAPI(apiKey, systemPrompt, sanitizedTask, model);
  } catch (apiError) {
    await sleep(5000);
    try {
      response = await callClaudeAPI(apiKey, systemPrompt, sanitizedTask, model);
    } catch (retryError) {
      if (memory) {
        memory.logDaily(`Claude API unreachable for ${agentName}: ${retryError.message}`);
      }
      return { action: 'skip', reason: 'api-unreachable' };
    }
  }

  budget.spent += cost;

  const result = parseSubagentResponse(response);

  const actionableTypes = ['file_edit', 'run_command', 'fix'];
  const needsValidation = result.type && actionableTypes.includes(result.type);

  if (needsValidation) {
    const validation = OutputValidator.validateAction(result);
    if (!validation.valid) {
      if (memory) {
        memory.logDaily(`Output validation failed for ${agentName}: ${validation.reasons.join('; ')}`);
      }
      return { action: 'queue', reason: `validation-failed: ${validation.reasons[0]}`, originalResponse: result };
    }
  }

  if (memory) {
    memory.logDaily(`${agentName} (${model}): ${result.action} — $${cost.toFixed(3)}`);
  }

  return result;
}

module.exports = {
  delegateToSubagent,
  loadSubagentDefinition,
  estimateCost,
  parseSubagentResponse,
  callClaudeAPI,
  MODEL_MAP,
  COST_ESTIMATES,
};
