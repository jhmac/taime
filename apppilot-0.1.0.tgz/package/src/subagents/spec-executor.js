'use strict';

const fs = require('fs');
const path = require('path');
const { delegateToSubagent } = require('./dispatcher');

async function executeSpec(spec, options = {}) {
  const { context, budget, memory, apiKey, identityDir, templatesDir, dryRun, projectRoot } = options;

  let currentCode = '';
  if (spec.filePath && projectRoot) {
    const fullPath = path.join(projectRoot, spec.filePath);
    try {
      currentCode = fs.readFileSync(fullPath, 'utf-8');
    } catch {}
  }

  const task = {
    spec,
    currentCode,
  };

  let result;
  try {
    result = await delegateToSubagent('spec-executor', task, {
      context, budget, memory, apiKey, identityDir, templatesDir, dryRun,
    });
  } catch (err) {
    return { status: 'stuck', reason: `dispatcher-error: ${err.message}` };
  }

  if (!result) {
    return { status: 'stuck', reason: 'no-response' };
  }

  if (result.action === 'skip') {
    return { status: 'stuck', reason: result.reason || 'skipped' };
  }

  if (result.action === 'dry-run') {
    return { status: 'dry-run', spec };
  }

  if (typeof result.raw === 'string' && result.raw.trim().startsWith('SPEC_COMPLETE')) {
    return { status: 'SPEC_COMPLETE' };
  }

  if (result.status === 'SPEC_COMPLETE') {
    return { status: 'SPEC_COMPLETE' };
  }

  if (result.status === 'change' && result.filePath && result.oldCode !== undefined && result.newCode !== undefined) {
    return {
      status: 'change',
      filePath: result.filePath,
      oldCode: result.oldCode,
      newCode: result.newCode,
      description: result.description || '',
    };
  }

  if (result.status === 'stuck') {
    return { status: 'stuck', reason: result.reason || 'unknown' };
  }

  return { status: 'stuck', reason: 'unrecognized-response' };
}

module.exports = {
  executeSpec,
};
