module.exports = {
  testMatch: ['**/tests/**/*.test.js'],
  modulePathIgnorePatterns: [
    '<rootDir>/../.cache/',
    '<rootDir>/../node_modules/',
  ],
  haste: {
    forceNodeFilesystemAPI: true,
    enableSymlinks: false,
  },
};
