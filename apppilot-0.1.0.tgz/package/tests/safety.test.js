'use strict';

const { isPathSafe, _parseAgentsSections, _matchGlob } = require('../src/safety');

describe('Safety Module', () => {
  const agentsContext = {
    content: [
      '# Agents',
      '',
      '## Safe to Auto-Modify',
      '- src/**',
      '- lib/*',
      '- config/app.js',
      '',
      '## Never Modify',
      '- config/secrets.js',
      '- deploy/**',
    ].join('\n'),
  };

  describe('isPathSafe', () => {
    test('allows files in safe glob patterns', () => {
      expect(isPathSafe('src/app.js', agentsContext)).toEqual({ safe: true, reason: expect.stringContaining('src/**') });
      expect(isPathSafe('src/deep/nested/file.js', agentsContext)).toEqual({ safe: true, reason: expect.stringContaining('src/**') });
    });

    test('allows single-level glob matches', () => {
      expect(isPathSafe('lib/utils.js', agentsContext)).toEqual({ safe: true, reason: expect.stringContaining('lib/*') });
    });

    test('blocks deep paths for single-level glob', () => {
      expect(isPathSafe('lib/deep/file.js', agentsContext)).toEqual({ safe: false, reason: expect.any(String) });
    });

    test('allows exact path matches', () => {
      expect(isPathSafe('config/app.js', agentsContext)).toEqual({ safe: true, reason: expect.stringContaining('config/app.js') });
    });

    test('blocks paths in protected section', () => {
      const result = isPathSafe('config/secrets.js', agentsContext);
      expect(result.safe).toBe(false);
      expect(result.reason).toContain('protected');
    });

    test('blocks paths under protected glob', () => {
      const result = isPathSafe('deploy/production.yml', agentsContext);
      expect(result.safe).toBe(false);
      expect(result.reason).toContain('protected');
    });

    test('always blocks identity files regardless of agents context', () => {
      const permissiveContext = { content: '## Safe to Auto-Modify\n- **' };
      expect(isPathSafe('SOUL.md', permissiveContext).safe).toBe(false);
      expect(isPathSafe('AGENTS.md', permissiveContext).safe).toBe(false);
      expect(isPathSafe('IDENTITY.md', permissiveContext).safe).toBe(false);
      expect(isPathSafe('HEARTBEAT.md', permissiveContext).safe).toBe(false);
      expect(isPathSafe('TOOLS.md', permissiveContext).safe).toBe(false);
      expect(isPathSafe('USER.md', permissiveContext).safe).toBe(false);
    });

    test('blocks path traversal', () => {
      const result = isPathSafe('../etc/passwd', agentsContext);
      expect(result.safe).toBe(false);
      expect(result.reason).toContain('traversal');
    });

    test('handles empty or invalid input', () => {
      expect(isPathSafe('', agentsContext).safe).toBe(false);
      expect(isPathSafe(null, agentsContext).safe).toBe(false);
      expect(isPathSafe(undefined, agentsContext).safe).toBe(false);
    });

    test('handles missing agents context', () => {
      expect(isPathSafe('src/app.js', null).safe).toBe(false);
      expect(isPathSafe('src/app.js', {}).safe).toBe(false);
    });

    test('protected overrides safe', () => {
      const context = {
        content: '## Safe to Auto-Modify\n- config/**\n\n## Never Modify\n- config/secrets.js',
      };
      expect(isPathSafe('config/app.js', context).safe).toBe(true);
      expect(isPathSafe('config/secrets.js', context).safe).toBe(false);
    });
  });

  describe('_parseAgentsSections', () => {
    test('extracts safe and protected paths', () => {
      const result = _parseAgentsSections(agentsContext);
      expect(result.safePaths).toContain('src/**');
      expect(result.safePaths).toContain('lib/*');
      expect(result.protectedPaths).toContain('config/secrets.js');
      expect(result.protectedPaths).toContain('deploy/**');
    });

    test('returns empty for null context', () => {
      const result = _parseAgentsSections(null);
      expect(result.safePaths).toEqual([]);
      expect(result.protectedPaths).toEqual([]);
    });

    test('handles context with no safe section', () => {
      const result = _parseAgentsSections({ content: '# Just a title\n\nSome text.' });
      expect(result.safePaths).toEqual([]);
    });

    test('handles "Do Not Modify" section header variant', () => {
      const ctx = { content: '## Do Not Modify\n- secrets/**' };
      const result = _parseAgentsSections(ctx);
      expect(result.protectedPaths).toContain('secrets/**');
    });

    test('handles "Protected" section header variant', () => {
      const ctx = { content: '## Protected\n- .env' };
      const result = _parseAgentsSections(ctx);
      expect(result.protectedPaths).toContain('.env');
    });
  });

  describe('_matchGlob', () => {
    test('matches double-star glob', () => {
      expect(_matchGlob('src/a/b/c.js', 'src/**')).toBe(true);
      expect(_matchGlob('src/file.js', 'src/**')).toBe(true);
      expect(_matchGlob('other/file.js', 'src/**')).toBe(false);
    });

    test('matches single-star glob (one level only)', () => {
      expect(_matchGlob('lib/utils.js', 'lib/*')).toBe(true);
      expect(_matchGlob('lib/deep/file.js', 'lib/*')).toBe(false);
    });

    test('matches exact path', () => {
      expect(_matchGlob('config/app.js', 'config/app.js')).toBe(true);
      expect(_matchGlob('config/other.js', 'config/app.js')).toBe(false);
    });

    test('handles wildcard in filename', () => {
      expect(_matchGlob('test.js', '*.js')).toBe(true);
      expect(_matchGlob('test.ts', '*.js')).toBe(false);
    });
  });
});
