'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const { Orchestrator, SUBAGENT_ORDER } = require('../src/orchestrator');
const { loadSubagentDefinition, estimateCost, parseSubagentResponse } = require('../src/subagents/dispatcher');

function createTestProject() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'apppilot-orch-'));

  fs.writeFileSync(path.join(dir, 'SOUL.md'), '# Test Soul\n\nYou are a test agent.');
  fs.writeFileSync(path.join(dir, 'AGENTS.md'), '# Test Agents\n\n## Safe to Auto-Modify\n- src/**');
  fs.writeFileSync(path.join(dir, 'IDENTITY.md'), '# Test Identity');
  fs.writeFileSync(path.join(dir, 'HEARTBEAT.md'), [
    '# Heartbeat Config',
    '- Max API spend per heartbeat: $2.00',
    '- Budget warning threshold: $1.50',
    '- Performance degradation alert: >25% increase in p95 response time',
    '- Error escalation: 5+ occurrences',
    '- Health check timeout: 15 seconds',
  ].join('\n'));

  fs.mkdirSync(path.join(dir, 'subagents'), { recursive: true });
  fs.writeFileSync(path.join(dir, 'subagents', 'error-resolver.md'), [
    '---',
    'name: error-resolver',
    'model: haiku',
    '---',
    'You are the error resolver.',
  ].join('\n'));

  return dir;
}

function cleanDir(dir) {
  fs.rmSync(dir, { recursive: true, force: true });
}

describe('Orchestrator', () => {
  let projectDir;

  beforeEach(() => {
    projectDir = createTestProject();
  });

  afterEach(() => {
    cleanDir(projectDir);
  });

  test('initializes with correct defaults', () => {
    const orch = new Orchestrator({ projectRoot: projectDir });
    expect(orch.projectRoot).toBe(projectDir);
    expect(orch.dryRun).toBe(false);
  });

  test('initialize loads context and heartbeat config', () => {
    const orch = new Orchestrator({ projectRoot: projectDir, identityDir: projectDir });
    orch.initialize();
    expect(orch.context.soul).not.toBeNull();
    expect(orch.context.agents).not.toBeNull();
    expect(orch.heartbeatConfig.maxBudget).toBe(2.0);
    expect(orch.heartbeatConfig.warningBudget).toBe(1.5);
    expect(orch.heartbeatConfig.perfThreshold).toBe(25);
    expect(orch.heartbeatConfig.errorEscalationCount).toBe(5);
  });

  test('halts on identity tampering', async () => {
    const orch1 = new Orchestrator({
      projectRoot: projectDir,
      identityDir: projectDir,
      dryRun: true,
    });
    orch1.initialize();

    fs.writeFileSync(path.join(projectDir, 'SOUL.md'), '# TAMPERED SOUL');

    const orch2 = new Orchestrator({
      projectRoot: projectDir,
      identityDir: projectDir,
      dryRun: true,
    });

    const result = await orch2.runHeartbeatCycle();
    expect(result.status).toBe('halted');
    expect(result.errors[0].type).toBe('identity_tampering');
  });

  test('logs daily on identity tampering', async () => {
    const orch1 = new Orchestrator({
      projectRoot: projectDir,
      identityDir: projectDir,
      dryRun: true,
    });
    orch1.initialize();

    fs.writeFileSync(path.join(projectDir, 'SOUL.md'), '# TAMPERED');

    const orch2 = new Orchestrator({
      projectRoot: projectDir,
      identityDir: projectDir,
      dryRun: true,
    });
    await orch2.runHeartbeatCycle();

    const dailyDir = path.join(projectDir, '.apppilot', 'daily');
    const files = fs.readdirSync(dailyDir);
    expect(files.length).toBeGreaterThan(0);
    const content = fs.readFileSync(path.join(dailyDir, files[0]), 'utf-8');
    expect(content).toContain('CRITICAL');
    expect(content).toContain('tampering');
  });

  test('dry run completes with all phases', async () => {
    const orch = new Orchestrator({
      projectRoot: projectDir,
      identityDir: projectDir,
      dryRun: true,
    });

    const result = await orch.runHeartbeatCycle();
    expect(result.status).toBe('completed');
    expect(result.steps.length).toBeGreaterThan(0);

    const stepNames = result.steps.map(s => s.step);
    expect(stepNames).toContain('identity_check');
    expect(stepNames).toContain('process_error_log');
    expect(stepNames).toContain('health_check');
    expect(stepNames).toContain('perf_check');
    expect(stepNames).toContain('approved_queue');
  });

  test('health check passes in dry run mode', async () => {
    const orch = new Orchestrator({
      projectRoot: projectDir,
      identityDir: projectDir,
      dryRun: true,
    });

    const result = await orch.runHeartbeatCycle();
    const healthStep = result.steps.find(s => s.step === 'health_check');
    expect(healthStep.status).toBe('passed');
  });

  test('respects budget limit via dispatcher', async () => {
    const orch = new Orchestrator({
      projectRoot: projectDir,
      identityDir: projectDir,
      dryRun: true,
    });
    orch.initialize();

    const budget = { spent: 10, max: 2 };
    const result = await orch._runSubagent('error-resolver', budget, {});
    expect(result.action).toBe('skip');
    expect(result.reason).toContain('budget');
  });

  test('approved queue processes files via ralph-loop', async () => {
    const orch = new Orchestrator({
      projectRoot: projectDir,
      identityDir: projectDir,
      dryRun: true,
    });
    orch.initialize();

    const queueDir = path.join(projectDir, '.apppilot', 'approved-queue');
    fs.mkdirSync(queueDir, { recursive: true });
    fs.writeFileSync(path.join(queueDir, '001-fix.json'), JSON.stringify({
      filePath: 'src/app.js',
      newCode: 'console.log("fixed");',
      testCommand: 'npm test',
    }));

    const budget = { spent: 0, max: 2.0 };
    const result = await orch._processApprovedQueue(budget);
    expect(result.processed + result.skipped).toBe(1);
  });

  test('approved queue skips when budget exhausted', async () => {
    const orch = new Orchestrator({
      projectRoot: projectDir,
      identityDir: projectDir,
      dryRun: true,
    });
    orch.initialize();

    const queueDir = path.join(projectDir, '.apppilot', 'approved-queue');
    fs.mkdirSync(queueDir, { recursive: true });
    fs.writeFileSync(path.join(queueDir, '001-fix.json'), JSON.stringify({
      filePath: 'src/app.js',
      newCode: 'console.log("fixed");',
    }));

    const budget = { spent: 5, max: 2.0 };
    const result = await orch._processApprovedQueue(budget);
    expect(result.processed).toBe(0);
    expect(result.skipped).toBe(1);
  });

  test('approved queue returns empty when no queue directory', async () => {
    const orch = new Orchestrator({
      projectRoot: projectDir,
      identityDir: projectDir,
      dryRun: true,
    });
    orch.initialize();

    const budget = { spent: 0, max: 2.0 };
    const result = await orch._processApprovedQueue(budget);
    expect(result.processed).toBe(0);
    expect(result.skipped).toBe(0);
  });

  test('heartbeat writes daily log summary on completion', async () => {
    const orch = new Orchestrator({
      projectRoot: projectDir,
      identityDir: projectDir,
      dryRun: true,
    });

    await orch.runHeartbeatCycle();

    const dailyDir = path.join(projectDir, '.apppilot', 'daily');
    const files = fs.readdirSync(dailyDir);
    expect(files.length).toBeGreaterThan(0);
    const content = fs.readFileSync(path.join(dailyDir, files[0]), 'utf-8');
    expect(content).toContain('Heartbeat complete');
    expect(content).toContain('Budget');
  });

  test('heartbeat updates dashboard status', async () => {
    const orch = new Orchestrator({
      projectRoot: projectDir,
      identityDir: projectDir,
      dryRun: true,
    });

    await orch.runHeartbeatCycle();
    expect(orch.dashboardStatus).not.toBeNull();
    expect(orch.dashboardStatus.status).toBe('complete');
    expect(orch.dashboardStatus.data.budget).toBeDefined();
    expect(orch.dashboardStatus.data.duration).toBeDefined();
  });

  test('heartbeat runs backup cleanup', async () => {
    const orch = new Orchestrator({
      projectRoot: projectDir,
      identityDir: projectDir,
      dryRun: true,
    });
    orch.initialize();

    const spy = jest.spyOn(orch.memory, 'cleanupOldBackups');

    await orch.runHeartbeatCycle();
    expect(spy).toHaveBeenCalledWith(50);
    spy.mockRestore();
  });

  test('heartbeat processes error log', async () => {
    const orch = new Orchestrator({
      projectRoot: projectDir,
      identityDir: projectDir,
      dryRun: true,
    });

    const result = await orch.runHeartbeatCycle();
    const errorLogStep = result.steps.find(s => s.step === 'process_error_log');
    expect(errorLogStep).toBeDefined();
    expect(errorLogStep.status).toBe('completed');
  });

  test('_checkAppHealth returns true in dry run', async () => {
    const orch = new Orchestrator({
      projectRoot: projectDir,
      identityDir: projectDir,
      dryRun: true,
    });
    const healthy = await orch._checkAppHealth(5000);
    expect(healthy).toBe(true);
  });

  test('_collectValidActions filters blocked actions', () => {
    const orch = new Orchestrator({
      projectRoot: projectDir,
      identityDir: projectDir,
    });

    const result = { actions: [], errors: [] };
    orch._collectValidActions([
      { type: 'file_edit', filePath: 'src/ok.js', newCode: 'ok' },
      { type: 'file_edit', filePath: 'SOUL.md', newCode: 'tamper' },
    ], result);

    expect(result.actions.length).toBe(1);
    expect(result.errors.length).toBe(1);
    expect(result.errors[0].type).toBe('action_blocked');
  });

  test('_subagentOptions provides correct options', () => {
    const orch = new Orchestrator({
      projectRoot: projectDir,
      identityDir: projectDir,
      dryRun: true,
    });
    orch.initialize();

    const budget = { spent: 0, max: 2 };
    const opts = orch._subagentOptions(budget);
    expect(opts.context).toBe(orch.context);
    expect(opts.budget).toBe(budget);
    expect(opts.dryRun).toBe(true);
    expect(opts.identityDir).toBe(projectDir);
    expect(opts.dataDir).toBeDefined();
  });
});

describe('Dispatcher functions', () => {
  let projectDir;

  beforeEach(() => {
    projectDir = createTestProject();
  });

  afterEach(() => {
    cleanDir(projectDir);
  });

  test('loadSubagentDefinition reads from identity dir', () => {
    const def = loadSubagentDefinition('error-resolver', projectDir);
    expect(def).toContain('error resolver');
    expect(def).toContain('model: haiku');
  });

  test('loadSubagentDefinition falls back for missing agent', () => {
    const def = loadSubagentDefinition('nonexistent', projectDir);
    expect(def).toContain('nonexistent');
    expect(def).toContain('model: sonnet');
  });

  test('estimateCost returns expected values', () => {
    expect(estimateCost('haiku')).toBe(0.005);
    expect(estimateCost('sonnet')).toBe(0.02);
    expect(estimateCost('opus')).toBe(0.10);
    expect(estimateCost('unknown')).toBe(0.02);
  });

  test('parseSubagentResponse extracts JSON', () => {
    const result = parseSubagentResponse('Here is the result: {"action": "fix", "file": "index.js"}');
    expect(result.action).toBe('fix');
  });

  test('parseSubagentResponse handles non-JSON', () => {
    const result = parseSubagentResponse('No JSON here, just text.');
    expect(result.action).toBe('queue');
    expect(result.reason).toBe('parse-failed');
  });
});

describe('SUBAGENT_ORDER', () => {
  test('has the correct execution order', () => {
    expect(SUBAGENT_ORDER).toEqual([
      'error-resolver',
      'perf-optimizer',
      'codebase-intel',
      'spec-executor',
      'self-improver',
    ]);
  });
});
