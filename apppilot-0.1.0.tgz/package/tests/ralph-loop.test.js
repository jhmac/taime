'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const { executeRalphLoop, _moveSpec } = require('../src/ralph-loop');
const { MemoryStore } = require('../src/memory');
const { loadContext } = require('../src/context-loader');

function createTestProject() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'apppilot-ralph-'));
  fs.writeFileSync(path.join(dir, 'SOUL.md'), '# Test Soul\n\nYou are a test agent.');
  fs.writeFileSync(path.join(dir, 'AGENTS.md'), '# Test Agents\n\n## Safe to Auto-Modify\n- src/**');
  fs.writeFileSync(path.join(dir, 'IDENTITY.md'), '# Test Identity');
  fs.writeFileSync(path.join(dir, 'HEARTBEAT.md'), '# Heartbeat\n- Max API spend per heartbeat: $2.00');
  fs.mkdirSync(path.join(dir, 'src'), { recursive: true });
  fs.writeFileSync(path.join(dir, 'src', 'app.js'), 'const x = null;\nconsole.log(x);');
  return dir;
}

function cleanDir(dir) {
  fs.rmSync(dir, { recursive: true, force: true });
}

describe('Ralph Loop', () => {
  let projectDir;
  let dataDir;
  let context;
  let memory;

  beforeEach(() => {
    projectDir = createTestProject();
    dataDir = path.join(projectDir, '.apppilot');
    context = loadContext(projectDir);
    memory = new MemoryStore(dataDir);
    memory.initialize();
  });

  afterEach(() => {
    cleanDir(projectDir);
  });

  test('returns failed for unreadable spec', async () => {
    const result = await executeRalphLoop('/tmp/nonexistent-spec.json', context, { spent: 0, max: 2 }, {
      projectRoot: projectDir,
      dataDir,
      memory,
      dryRun: true,
    });
    expect(result.status).toBe('failed');
    expect(result.reason).toContain('Cannot read spec');
    expect(result.iterations).toBe(0);
  });

  test('returns dry-run in dry run mode', async () => {
    const specDir = path.join(dataDir, 'approved-queue');
    fs.mkdirSync(specDir, { recursive: true });
    const specPath = path.join(specDir, 'test-spec.json');
    fs.writeFileSync(specPath, JSON.stringify({
      filePath: 'src/app.js',
      successCriteria: 'Add null check',
    }));

    const result = await executeRalphLoop(specPath, context, { spent: 0, max: 2 }, {
      projectRoot: projectDir,
      dataDir,
      memory,
      dryRun: true,
      identityDir: projectDir,
    });

    expect(result.status).toBe('dry-run');
    expect(result.iterations).toBe(1);
  });

  test('returns stuck when budget exceeded', async () => {
    const specDir = path.join(dataDir, 'approved-queue');
    fs.mkdirSync(specDir, { recursive: true });
    const specPath = path.join(specDir, 'test-spec.json');
    fs.writeFileSync(specPath, JSON.stringify({
      filePath: 'src/app.js',
      successCriteria: 'Fix bug',
    }));

    const result = await executeRalphLoop(specPath, context, { spent: 5, max: 2 }, {
      projectRoot: projectDir,
      dataDir,
      memory,
      dryRun: false,
      identityDir: projectDir,
    });

    expect(result.status).toBe('stuck');
  });

  test('moves spec to completed/ or failed/ after execution', async () => {
    const specDir = path.join(dataDir, 'approved-queue');
    fs.mkdirSync(specDir, { recursive: true });
    const specPath = path.join(specDir, 'test-spec.json');
    fs.writeFileSync(specPath, JSON.stringify({
      filePath: 'src/app.js',
      successCriteria: 'Test',
    }));

    await executeRalphLoop(specPath, context, { spent: 5, max: 2 }, {
      projectRoot: projectDir,
      dataDir,
      memory,
      dryRun: false,
      identityDir: projectDir,
    });

    expect(fs.existsSync(specPath)).toBe(false);
    const failedDir = path.join(dataDir, 'failed');
    expect(fs.existsSync(failedDir)).toBe(true);
    const files = fs.readdirSync(failedDir);
    expect(files.length).toBe(1);
  });
});

describe('_moveSpec', () => {
  let tempDir;

  beforeEach(() => {
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'apppilot-move-'));
  });

  afterEach(() => {
    cleanDir(tempDir);
  });

  test('moves completed spec to completed/', () => {
    const specPath = path.join(tempDir, 'spec.json');
    fs.writeFileSync(specPath, '{"test": true}');

    _moveSpec(specPath, 'completed', tempDir);

    expect(fs.existsSync(specPath)).toBe(false);
    expect(fs.existsSync(path.join(tempDir, 'completed', 'spec.json'))).toBe(true);
  });

  test('moves failed spec to failed/', () => {
    const specPath = path.join(tempDir, 'spec.json');
    fs.writeFileSync(specPath, '{"test": true}');

    _moveSpec(specPath, 'stuck', tempDir);

    expect(fs.existsSync(specPath)).toBe(false);
    expect(fs.existsSync(path.join(tempDir, 'failed', 'spec.json'))).toBe(true);
  });
});
