'use strict';

const { MetricsCollector, apppilotMiddleware } = require('../src/middleware');

function mockReq(overrides = {}) {
  return {
    method: 'GET',
    path: '/',
    headers: {},
    query: {},
    ...overrides,
  };
}

function mockRes() {
  const res = {
    statusCode: 200,
    _headers: {},
    _body: null,
    _ended: false,
    type(t) { res._headers['content-type'] = t; return res; },
    json(data) { res._body = data; res._ended = true; },
    send(data) { res._body = data; res._ended = true; },
    status(code) { res.statusCode = code; return res; },
    end() { res._ended = true; },
  };
  return res;
}

describe('MetricsCollector', () => {
  let collector;

  beforeEach(() => {
    collector = new MetricsCollector();
  });

  test('records request entries', () => {
    collector.recordRequest({ method: 'GET', path: '/', statusCode: 200, duration: 50 });
    collector.recordRequest({ method: 'POST', path: '/api', statusCode: 201, duration: 100 });
    expect(collector.requests.length).toBe(2);
  });

  test('limits stored requests to maxEntries', () => {
    for (let i = 0; i < 1100; i++) {
      collector.recordRequest({ method: 'GET', path: '/', statusCode: 200, duration: 10 });
    }
    expect(collector.requests.length).toBeLessThanOrEqual(1000);
  });

  test('records errors', () => {
    collector.recordError({ message: 'Test error', stack: 'stack trace' });
    expect(collector.errorLog.length).toBe(1);
    expect(collector.errorLog[0].message).toBe('Test error');
  });

  test('getStats returns metrics summary', () => {
    collector.recordRequest({ method: 'GET', path: '/', statusCode: 200, duration: 50 });
    collector.recordRequest({ method: 'GET', path: '/', statusCode: 500, duration: 200 });
    const stats = collector.getStats();
    expect(stats.totalRequests).toBe(2);
    expect(stats.recentRequests).toBe(2);
    expect(typeof stats.p50).toBe('number');
    expect(typeof stats.p95).toBe('number');
    expect(typeof stats.uptimeMs).toBe('number');
  });

  test('getRecentErrors returns limited errors', () => {
    for (let i = 0; i < 30; i++) {
      collector.recordError({ message: `Error ${i}` });
    }
    const recent = collector.getRecentErrors(5);
    expect(recent.length).toBe(5);
  });

  test('percentile handles empty array', () => {
    const stats = collector.getStats();
    expect(stats.p50).toBe(0);
  });
});

describe('apppilotMiddleware', () => {
  test('creates middleware function', () => {
    const mw = apppilotMiddleware();
    expect(typeof mw).toBe('function');
  });

  test('responds to health check', () => {
    const mw = apppilotMiddleware();
    const req = mockReq({ method: 'GET', path: '/health' });
    const res = mockRes();
    mw(req, res, () => {});
    expect(res._body).not.toBeNull();
    expect(res._body.status).toBe('ok');
  });

  test('blocks dashboard without auth key', () => {
    const mw = apppilotMiddleware({ internalKey: 'secret123' });
    const req = mockReq({ method: 'GET', path: '/apppilot/dashboard' });
    const res = mockRes();
    mw(req, res, () => {});
    expect(res.statusCode).toBe(401);
  });

  test('allows dashboard with correct auth key in header', () => {
    const mw = apppilotMiddleware({ internalKey: 'secret123' });
    const req = mockReq({
      method: 'GET',
      path: '/apppilot/dashboard',
      headers: { 'x-apppilot-key': 'secret123' },
    });
    const res = mockRes();
    mw(req, res, () => {});
    expect(res.statusCode).toBe(200);
    expect(res._body).toContain('AppPilot Dashboard');
  });

  test('allows dashboard with correct auth key in query', () => {
    const mw = apppilotMiddleware({ internalKey: 'secret123' });
    const req = mockReq({
      method: 'GET',
      path: '/apppilot/dashboard',
      query: { key: 'secret123' },
    });
    const res = mockRes();
    mw(req, res, () => {});
    expect(res.statusCode).toBe(200);
  });

  test('allows dashboard when no internal key configured', () => {
    const mw = apppilotMiddleware({ internalKey: null });
    const req = mockReq({ method: 'GET', path: '/apppilot/dashboard' });
    const res = mockRes();
    mw(req, res, () => {});
    expect(res.statusCode).toBe(200);
  });

  test('calls next for normal requests with metrics', () => {
    const mw = apppilotMiddleware();
    const req = mockReq({ method: 'GET', path: '/api/users' });
    const res = mockRes();
    let nextCalled = false;
    mw(req, res, () => { nextCalled = true; });
    expect(nextCalled).toBe(true);
  });

  test('calls next for normal requests without metrics', () => {
    const mw = apppilotMiddleware({ enableMetrics: false });
    const req = mockReq({ method: 'GET', path: '/api/users' });
    const res = mockRes();
    let nextCalled = false;
    mw(req, res, () => { nextCalled = true; });
    expect(nextCalled).toBe(true);
  });

  test('custom dashboard path', () => {
    const mw = apppilotMiddleware({ dashboardPath: '/admin/pilot', internalKey: null });
    const req = mockReq({ method: 'GET', path: '/admin/pilot' });
    const res = mockRes();
    mw(req, res, () => {});
    expect(res._body).toContain('AppPilot Dashboard');
  });

  test('escapes HTML in error messages on dashboard', () => {
    const mw = apppilotMiddleware({ internalKey: null });
    mw._collector.recordError({ message: '<script>alert("xss")</script>' });
    const req = mockReq({ method: 'GET', path: '/apppilot/dashboard' });
    const res = mockRes();
    mw(req, res, () => {});
    expect(res._body).not.toContain('<script>');
    expect(res._body).toContain('&lt;script&gt;');
  });
});
