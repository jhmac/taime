'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const { delegateToSubagent, loadSubagentDefinition, estimateCost, parseSubagentResponse } = require('../src/subagents/dispatcher');
const { resolveError, _getSafePaths, _isPathSafe, _writeSpecFile, _writeToPendingQueue } = require('../src/subagents/error-resolver');
const { optimizePerformance } = require('../src/subagents/perf-optimizer');
const { analyzeCodebase, _listProjectFiles } = require('../src/subagents/codebase-intel');
const { executeSpec } = require('../src/subagents/spec-executor');
const { selfImprove } = require('../src/subagents/self-improver');
const { loadContext } = require('../src/context-loader');
const { MemoryStore } = require('../src/memory');

function createTestProject() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'apppilot-sub-'));
  fs.writeFileSync(path.join(dir, 'SOUL.md'), '# Test Soul\n\nYou are a test agent.');
  fs.writeFileSync(path.join(dir, 'AGENTS.md'), '# Test Agents\n\n## Safe to Auto-Modify\n- src/**\n- lib/*');
  fs.writeFileSync(path.join(dir, 'IDENTITY.md'), '# Test Identity');
  fs.writeFileSync(path.join(dir, 'HEARTBEAT.md'), '# Heartbeat\n- Max API spend per heartbeat: $2.00');

  fs.mkdirSync(path.join(dir, 'subagents'), { recursive: true });
  fs.writeFileSync(path.join(dir, 'subagents', 'error-resolver.md'), [
    '---', 'name: error-resolver', 'model: haiku', '---', 'You are the error resolver.',
  ].join('\n'));

  fs.mkdirSync(path.join(dir, 'src'), { recursive: true });
  fs.writeFileSync(path.join(dir, 'src', 'app.js'), 'console.log("hello");');

  return dir;
}

function cleanDir(dir) {
  fs.rmSync(dir, { recursive: true, force: true });
}

describe('Dispatcher', () => {
  let projectDir;
  let context;
  let memory;

  beforeEach(() => {
    projectDir = createTestProject();
    context = loadContext(projectDir);
    memory = new MemoryStore(path.join(projectDir, '.apppilot'));
    memory.initialize();
  });

  afterEach(() => {
    cleanDir(projectDir);
  });

  test('delegateToSubagent skips when budget exceeded', async () => {
    const budget = { spent: 2, max: 1 };
    const result = await delegateToSubagent('error-resolver', { test: true }, {
      context, budget, memory, identityDir: projectDir, dryRun: false,
    });
    expect(result.action).toBe('skip');
    expect(result.reason).toBe('budget-exceeded');
  });

  test('delegateToSubagent returns dry-run result', async () => {
    const budget = { spent: 0, max: 2 };
    const result = await delegateToSubagent('error-resolver', { test: true }, {
      context, budget, memory, identityDir: projectDir, dryRun: true,
    });
    expect(result.action).toBe('dry-run');
    expect(result.subagent).toBe('error-resolver');
    expect(result.model).toBe('haiku');
  });

  test('delegateToSubagent skips when no API key', async () => {
    const budget = { spent: 0, max: 2 };
    const result = await delegateToSubagent('error-resolver', { test: true }, {
      context, budget, memory, identityDir: projectDir, dryRun: false, apiKey: null,
    });
    expect(result.action).toBe('skip');
    expect(result.reason).toBe('no-api-key');
  });

  test('loadSubagentDefinition reads project file', () => {
    const def = loadSubagentDefinition('error-resolver', projectDir);
    expect(def).toContain('error resolver');
  });

  test('loadSubagentDefinition falls back to templates', () => {
    const templatesDir = path.join(__dirname, '..', 'templates');
    const def = loadSubagentDefinition('perf-optimizer', '/tmp/nonexistent-dir', templatesDir);
    expect(def).toContain('perf-optimizer');
  });

  test('loadSubagentDefinition generates fallback for unknown agent', () => {
    const def = loadSubagentDefinition('unknown-agent', '/tmp/nonexistent-dir');
    expect(def).toContain('unknown-agent');
    expect(def).toContain('model: sonnet');
  });

  test('estimateCost returns correct values per model', () => {
    expect(estimateCost('haiku')).toBe(0.005);
    expect(estimateCost('sonnet')).toBe(0.02);
    expect(estimateCost('opus')).toBe(0.10);
    expect(estimateCost('unknown')).toBe(0.02);
  });

  test('parseSubagentResponse extracts JSON from mixed text', () => {
    const result = parseSubagentResponse('Here is result: {"action": "fix", "file": "app.js"}');
    expect(result.action).toBe('fix');
  });

  test('parseSubagentResponse returns queue on parse failure', () => {
    const result = parseSubagentResponse('No JSON here');
    expect(result.action).toBe('queue');
    expect(result.reason).toBe('parse-failed');
  });

  test('parseSubagentResponse handles non-string input', () => {
    const result = parseSubagentResponse(null);
    expect(result.action).toBe('queue');
    expect(result.reason).toBe('non-string-response');
  });

  test('parseSubagentResponse defaults action to queue if missing', () => {
    const result = parseSubagentResponse('{"file": "app.js", "code": "fixed"}');
    expect(result.action).toBe('queue');
  });
});

describe('Error Resolver', () => {
  let projectDir;
  let context;
  let memory;
  let dataDir;

  beforeEach(() => {
    projectDir = createTestProject();
    dataDir = path.join(projectDir, '.apppilot');
    context = loadContext(projectDir);
    memory = new MemoryStore(dataDir);
    memory.initialize();
  });

  afterEach(() => {
    cleanDir(projectDir);
  });

  test('resolveError delegates in dry run', async () => {
    const result = await resolveError(
      { message: 'TypeError: x is undefined', stack: 'at app.js:10', file: 'src/app.js' },
      { context, budget: { spent: 0, max: 2 }, memory, identityDir: projectDir, dryRun: true, dataDir }
    );
    expect(result.action).toBe('dry-run');
  });

  test('_getSafePaths extracts paths from agents context', () => {
    const paths = _getSafePaths(context);
    expect(paths).toContain('src/**');
    expect(paths).toContain('lib/*');
  });

  test('_getSafePaths returns empty for missing context', () => {
    expect(_getSafePaths(null)).toEqual([]);
    expect(_getSafePaths({})).toEqual([]);
  });

  test('_isPathSafe matches glob-style patterns', () => {
    const safePaths = ['src/**', 'lib/*'];
    expect(_isPathSafe('src/app.js', safePaths)).toBe(true);
    expect(_isPathSafe('src/deep/nested/file.js', safePaths)).toBe(true);
    expect(_isPathSafe('lib/utils.js', safePaths)).toBe(true);
    expect(_isPathSafe('lib/deep/file.js', safePaths)).toBe(false);
    expect(_isPathSafe('config/db.js', safePaths)).toBe(false);
    expect(_isPathSafe('SOUL.md', safePaths)).toBe(false);
  });

  test('_isPathSafe returns false for empty path or patterns', () => {
    expect(_isPathSafe('', ['src/**'])).toBe(false);
    expect(_isPathSafe('src/app.js', [])).toBe(false);
  });

  test('_writeSpecFile creates spec in approved-queue', () => {
    _writeSpecFile(dataDir, { filePath: 'src/app.js', newCode: 'fixed' });
    const queueDir = path.join(dataDir, 'approved-queue');
    expect(fs.existsSync(queueDir)).toBe(true);
    const files = fs.readdirSync(queueDir);
    expect(files.length).toBe(1);
    const content = JSON.parse(fs.readFileSync(path.join(queueDir, files[0]), 'utf-8'));
    expect(content.filePath).toBe('src/app.js');
  });

  test('_writeToPendingQueue creates entry in pending-queue', () => {
    _writeToPendingQueue(dataDir, { type: 'error-fix', error: { message: 'test' } });
    const pendingDir = path.join(dataDir, 'pending-queue');
    expect(fs.existsSync(pendingDir)).toBe(true);
    const files = fs.readdirSync(pendingDir);
    expect(files.length).toBe(1);
  });
});

describe('Performance Optimizer', () => {
  let projectDir;
  let context;

  beforeEach(() => {
    projectDir = createTestProject();
    context = loadContext(projectDir);
  });

  afterEach(() => {
    cleanDir(projectDir);
  });

  test('optimizePerformance delegates in dry run', async () => {
    const result = await optimizePerformance(
      [{ p95: 120 }, { p95: 150 }],
      { context, budget: { spent: 0, max: 2 }, identityDir: projectDir, dryRun: true, threshold: 25 }
    );
    expect(result.action).toBe('dry-run');
  });
});

describe('Codebase Intel', () => {
  let projectDir;
  let context;
  let dataDir;

  beforeEach(() => {
    projectDir = createTestProject();
    dataDir = path.join(projectDir, '.apppilot');
    context = loadContext(projectDir);
  });

  afterEach(() => {
    cleanDir(projectDir);
  });

  test('analyzeCodebase delegates in dry run', async () => {
    const memory = new MemoryStore(dataDir);
    memory.initialize();
    const result = await analyzeCodebase({
      context, budget: { spent: 0, max: 2 }, memory, identityDir: projectDir,
      dryRun: true, dataDir, projectRoot: projectDir,
    });
    expect(result.action).toBe('dry-run');
  });

  test('_listProjectFiles finds source files', () => {
    const files = _listProjectFiles(projectDir);
    expect(files.length).toBeGreaterThan(0);
    expect(files.some(f => f.includes('app.js'))).toBe(true);
  });

  test('_listProjectFiles ignores node_modules and .git', () => {
    fs.mkdirSync(path.join(projectDir, 'node_modules', 'pkg'), { recursive: true });
    fs.writeFileSync(path.join(projectDir, 'node_modules', 'pkg', 'index.js'), 'module.exports = {}');

    const files = _listProjectFiles(projectDir);
    expect(files.every(f => !f.includes('node_modules'))).toBe(true);
  });

  test('_listProjectFiles respects max file limit', () => {
    for (let i = 0; i < 5; i++) {
      fs.writeFileSync(path.join(projectDir, `file${i}.txt`), 'content');
    }
    const files = _listProjectFiles(projectDir, 3);
    expect(files.length).toBeLessThanOrEqual(3);
  });
});

describe('Spec Executor', () => {
  let projectDir;
  let context;

  beforeEach(() => {
    projectDir = createTestProject();
    context = loadContext(projectDir);
  });

  afterEach(() => {
    cleanDir(projectDir);
  });

  test('executeSpec returns dry-run in dry mode', async () => {
    const result = await executeSpec(
      { filePath: 'src/app.js', successCriteria: 'Null check added' },
      { context, budget: { spent: 0, max: 2 }, identityDir: projectDir, dryRun: true, projectRoot: projectDir }
    );
    expect(result.status).toBe('dry-run');
  });

  test('executeSpec reads current code from file', async () => {
    const result = await executeSpec(
      { filePath: 'src/app.js' },
      { context, budget: { spent: 0, max: 2 }, identityDir: projectDir, dryRun: true, projectRoot: projectDir }
    );
    expect(result.status).toBe('dry-run');
  });

  test('executeSpec returns stuck when budget exceeded', async () => {
    const result = await executeSpec(
      { filePath: 'src/app.js' },
      { context, budget: { spent: 5, max: 2 }, identityDir: projectDir, dryRun: false, projectRoot: projectDir }
    );
    expect(result.status).toBe('stuck');
    expect(result.reason).toContain('budget');
  });
});

describe('Self Improver', () => {
  let projectDir;
  let context;
  let memory;
  let dataDir;

  beforeEach(() => {
    projectDir = createTestProject();
    dataDir = path.join(projectDir, '.apppilot');
    context = loadContext(projectDir);
    memory = new MemoryStore(dataDir);
    memory.initialize();
  });

  afterEach(() => {
    cleanDir(projectDir);
  });

  test('selfImprove delegates in dry run', async () => {
    const result = await selfImprove({
      context, budget: { spent: 0, max: 2 }, memory, identityDir: projectDir, dryRun: true, dataDir,
    });
    expect(result.action).toBe('dry-run');
  });

  test('selfImprove writes to pending queue in dry run', async () => {
    await selfImprove({
      context, budget: { spent: 0, max: 2 }, memory, identityDir: projectDir, dryRun: true, dataDir,
    });
    const pendingDir = path.join(dataDir, 'pending-queue');
    expect(fs.existsSync(pendingDir)).toBe(true);
    const files = fs.readdirSync(pendingDir);
    expect(files.length).toBe(1);
    const content = JSON.parse(fs.readFileSync(path.join(pendingDir, files[0]), 'utf-8'));
    expect(content.type).toBe('self-improvement');
  });
});
