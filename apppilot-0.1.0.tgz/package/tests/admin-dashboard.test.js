'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const { createAdminDashboard } = require('../src/middleware/admin-dashboard');
const { MemoryStore } = require('../src/memory');
const { IdentityProtection, AuthRateLimiter } = require('../src/security');
const { MetricsCollector } = require('../src/middleware');

function makeTmpDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'apppilot-dash-'));
}

function mockReq(overrides = {}) {
  return {
    method: overrides.method || 'GET',
    path: overrides.path || '/',
    headers: overrides.headers || {},
    query: overrides.query || {},
    params: overrides.params || {},
    ip: overrides.ip || '127.0.0.1',
    connection: { remoteAddress: '127.0.0.1' },
    ...overrides,
  };
}

function mockRes() {
  const res = {
    statusCode: 200,
    _headers: {},
    _body: null,
    _type: null,
    status(code) { res.statusCode = code; return res; },
    json(data) { res._body = data; res._type = 'json'; return res; },
    send(data) { res._body = data; return res; },
    type(t) { res._type = t; return res; },
  };
  return res;
}

describe('Admin Dashboard', () => {
  let tmpDir, projectRoot, dataDir, memoryStore, collector, identity;
  const TEST_KEY = 'test-admin-key-12345';

  beforeEach(() => {
    tmpDir = makeTmpDir();
    projectRoot = tmpDir;
    dataDir = path.join(tmpDir, '.apppilot');

    fs.writeFileSync(path.join(projectRoot, 'SOUL.md'), '# TestAgent\n\nA test agent.');
    fs.writeFileSync(path.join(projectRoot, 'AGENTS.md'), '# Agents\n\n## Safe to Auto-Modify\n- src/**\n');

    memoryStore = new MemoryStore(dataDir);
    memoryStore.initialize();

    collector = new MetricsCollector();

    identity = new IdentityProtection(projectRoot, dataDir);
    identity.initialize();

    process.env.APPPILOT_INTERNAL_KEY = TEST_KEY;
  });

  afterEach(() => {
    delete process.env.APPPILOT_INTERNAL_KEY;
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  function createDashboard(overrides = {}) {
    return createAdminDashboard({
      memoryStore,
      metricsCollector: collector,
      identityProtection: identity,
      projectRoot,
      dataDir,
      ownerConfig: { internalKey: TEST_KEY },
      ...overrides,
    });
  }

  describe('Authentication', () => {
    test('rejects requests without auth key', () => {
      const dashboard = createDashboard();
      const req = mockReq({ headers: {} });
      const res = mockRes();
      let nextCalled = false;

      dashboard.authMiddleware(req, res, () => { nextCalled = true; });

      expect(res.statusCode).toBe(401);
      expect(res._body.error).toBe('Unauthorized');
      expect(nextCalled).toBe(false);
    });

    test('accepts requests with valid auth key in header', () => {
      const dashboard = createDashboard();
      const req = mockReq({ headers: { 'x-apppilot-key': TEST_KEY } });
      const res = mockRes();
      let nextCalled = false;

      dashboard.authMiddleware(req, res, () => { nextCalled = true; });

      expect(nextCalled).toBe(true);
    });

    test('accepts requests with valid auth key in query', () => {
      const dashboard = createDashboard();
      const req = mockReq({ query: { key: TEST_KEY } });
      const res = mockRes();
      let nextCalled = false;

      dashboard.authMiddleware(req, res, () => { nextCalled = true; });

      expect(nextCalled).toBe(true);
    });

    test('rejects requests with wrong auth key', () => {
      const dashboard = createDashboard();
      const req = mockReq({ headers: { 'x-apppilot-key': 'wrong-key' } });
      const res = mockRes();

      dashboard.authMiddleware(req, res, () => {});

      expect(res.statusCode).toBe(401);
    });

    test('rate limits after too many failed attempts', () => {
      const dashboard = createDashboard({
        ownerConfig: { internalKey: TEST_KEY, maxAuthAttempts: 3, authWindowMs: 60000 },
      });

      for (let i = 0; i < 4; i++) {
        const req = mockReq({ headers: { 'x-apppilot-key': 'wrong' }, ip: '1.2.3.4' });
        const res = mockRes();
        dashboard.authMiddleware(req, res, () => {});
      }

      const req = mockReq({ headers: { 'x-apppilot-key': TEST_KEY }, ip: '1.2.3.4' });
      const res = mockRes();
      dashboard.authMiddleware(req, res, () => {});

      expect(res.statusCode).toBe(429);
      expect(res._body.error).toContain('Too many');
    });
  });

  describe('GET /api/status', () => {
    test('returns status with agent name from SOUL.md', () => {
      const dashboard = createDashboard();
      const req = mockReq();
      const res = mockRes();

      dashboard.getStatus(req, res);

      expect(res._body.agentName).toBe('TestAgent');
      expect(res._body.status).toBe('healthy');
      expect(res._body.stats).toBeDefined();
      expect(res._body.stats.fixesApplied).toBe(0);
      expect(res._body.stats.errorsToday).toBe(0);
    });

    test('returns degraded status with many errors', () => {
      for (let i = 0; i < 6; i++) {
        memoryStore.addKnownError({
          signature: `err-${i}`,
          message: `Error ${i}`,
          status: 'new',
        });
      }

      const dashboard = createDashboard();
      const req = mockReq();
      const res = mockRes();

      dashboard.getStatus(req, res);

      expect(res._body.status).toBe('degraded');
    });

    test('returns alert status when identity files modified', () => {
      fs.writeFileSync(path.join(projectRoot, 'SOUL.md'), '# Modified Agent\n\nChanged.');

      const dashboard = createDashboard();
      const req = mockReq();
      const res = mockRes();

      dashboard.getStatus(req, res);

      expect(res._body.status).toBe('alert');
    });
  });

  describe('GET /api/feed', () => {
    test('returns empty feed when no activity', () => {
      const dashboard = createDashboard();
      const req = mockReq({ query: { limit: '10' } });
      const res = mockRes();

      dashboard.getFeed(req, res);

      expect(res._body.feed).toEqual([]);
    });

    test('returns feed entries with type classification', () => {
      memoryStore.logDaily('Heartbeat complete. Budget: $0.050/2.00. Duration: 3000ms.');
      memoryStore.logDaily('CRITICAL: Identity file tampering detected.');
      memoryStore.logDaily('Error in route /api/users');

      const dashboard = createDashboard();
      const req = mockReq({ query: { limit: '50' } });
      const res = mockRes();

      dashboard.getFeed(req, res);

      const feed = res._body.feed;
      expect(feed.length).toBe(3);

      const types = feed.map(f => f.type);
      expect(types).toContain('heartbeat');
      expect(types).toContain('critical');
      expect(types).toContain('error');
    });

    test('respects limit parameter', () => {
      for (let i = 0; i < 10; i++) {
        memoryStore.logDaily(`Entry ${i}`);
      }

      const dashboard = createDashboard();
      const req = mockReq({ query: { limit: '3' } });
      const res = mockRes();

      dashboard.getFeed(req, res);

      expect(res._body.feed.length).toBe(3);
    });

    test('caps limit at 200', () => {
      const dashboard = createDashboard();
      const req = mockReq({ query: { limit: '999' } });
      const res = mockRes();

      dashboard.getFeed(req, res);

      expect(res._body.feed).toBeDefined();
    });
  });

  describe('GET /api/errors', () => {
    test('returns errors sorted by occurrences', () => {
      memoryStore.addKnownError({ signature: 'low', message: 'Low error', status: 'new' });
      memoryStore.addKnownError({ signature: 'high', message: 'High error', status: 'new' });
      memoryStore.addKnownError({ signature: 'high', message: 'High error', status: 'new' });
      memoryStore.addKnownError({ signature: 'high', message: 'High error', status: 'new' });

      const dashboard = createDashboard();
      const req = mockReq();
      const res = mockRes();

      dashboard.getErrors(req, res);

      expect(res._body.errors[0].signature).toBe('high');
      expect(res._body.errors[0].occurrences).toBeGreaterThan(1);
    });
  });

  describe('GET /api/metrics', () => {
    test('returns current stats and history', () => {
      collector.recordRequest({ method: 'GET', path: '/', statusCode: 200, duration: 50 });
      collector.recordRequest({ method: 'GET', path: '/api', statusCode: 200, duration: 150 });

      memoryStore.saveMetricsSnapshot({ p95: 100, requests: 500 });

      const dashboard = createDashboard();
      const req = mockReq();
      const res = mockRes();

      dashboard.getMetrics(req, res);

      expect(res._body.current).toBeDefined();
      expect(res._body.history.length).toBe(1);
    });
  });

  describe('Queue Management', () => {
    test('GET /api/queue returns pending and approved items', () => {
      const pendingDir = path.join(dataDir, 'pending-queue');
      const approvedDir = path.join(dataDir, 'approved-queue');
      fs.mkdirSync(pendingDir, { recursive: true });
      fs.mkdirSync(approvedDir, { recursive: true });

      fs.writeFileSync(path.join(pendingDir, 'task-1.json'), JSON.stringify({
        title: 'Fix login bug',
        source: 'error-resolver',
      }));
      fs.writeFileSync(path.join(approvedDir, 'task-2.json'), JSON.stringify({
        title: 'Optimize query',
        source: 'perf-optimizer',
      }));

      const dashboard = createDashboard();
      const req = mockReq();
      const res = mockRes();

      dashboard.getQueue(req, res);

      expect(res._body.pending.length).toBe(1);
      expect(res._body.pending[0].id).toBe('task-1');
      expect(res._body.pending[0].title).toBe('Fix login bug');
      expect(res._body.approved.length).toBe(1);
    });

    test('POST /api/queue/:id/approve moves item to approved queue', () => {
      const pendingDir = path.join(dataDir, 'pending-queue');
      fs.mkdirSync(pendingDir, { recursive: true });
      fs.writeFileSync(path.join(pendingDir, 'task-abc.json'), JSON.stringify({
        title: 'Test task',
      }));

      const dashboard = createDashboard();
      const req = mockReq({ params: { id: 'task-abc' } });
      const res = mockRes();

      dashboard.approveQueueItem(req, res);

      expect(res._body.success).toBe(true);
      expect(res._body.action).toBe('approved');
      expect(fs.existsSync(path.join(pendingDir, 'task-abc.json'))).toBe(false);
      expect(fs.existsSync(path.join(dataDir, 'approved-queue', 'task-abc.json'))).toBe(true);
    });

    test('POST /api/queue/:id/reject moves item to rejected queue', () => {
      const pendingDir = path.join(dataDir, 'pending-queue');
      fs.mkdirSync(pendingDir, { recursive: true });
      fs.writeFileSync(path.join(pendingDir, 'task-xyz.json'), JSON.stringify({
        title: 'Risky task',
      }));

      const dashboard = createDashboard();
      const req = mockReq({ params: { id: 'task-xyz' } });
      const res = mockRes();

      dashboard.rejectQueueItem(req, res);

      expect(res._body.success).toBe(true);
      expect(res._body.action).toBe('rejected');
      expect(fs.existsSync(path.join(pendingDir, 'task-xyz.json'))).toBe(false);
      expect(fs.existsSync(path.join(dataDir, 'rejected-queue', 'task-xyz.json'))).toBe(true);
    });

    test('approve returns 404 for non-existent item', () => {
      const dashboard = createDashboard();
      const req = mockReq({ params: { id: 'nonexistent' } });
      const res = mockRes();

      dashboard.approveQueueItem(req, res);

      expect(res.statusCode).toBe(404);
    });

    test('reject returns 404 for non-existent item', () => {
      const dashboard = createDashboard();
      const req = mockReq({ params: { id: 'nonexistent' } });
      const res = mockRes();

      dashboard.rejectQueueItem(req, res);

      expect(res.statusCode).toBe(404);
    });

    test('approve returns 400 when id is missing', () => {
      const dashboard = createDashboard();
      const req = mockReq({ params: {} });
      const res = mockRes();

      dashboard.approveQueueItem(req, res);

      expect(res.statusCode).toBe(400);
    });
  });

  describe('GET /api/security', () => {
    test('returns checksums and valid integrity', () => {
      const dashboard = createDashboard();
      const req = mockReq();
      const res = mockRes();

      dashboard.getSecurity(req, res);

      expect(res._body.checksums).toBeDefined();
      expect(res._body.integrityValid).toBe(true);
      expect(res._body.changes).toEqual([]);
      expect(Object.keys(res._body.checksums)).toContain('SOUL.md');
    });

    test('reports modified files', () => {
      fs.writeFileSync(path.join(projectRoot, 'SOUL.md'), '# TAMPERED SOUL\n\nNew content.');

      const dashboard = createDashboard();
      const req = mockReq();
      const res = mockRes();

      dashboard.getSecurity(req, res);

      expect(res._body.integrityValid).toBe(false);
      expect(res._body.changes.length).toBeGreaterThan(0);
      expect(res._body.changes[0].file).toBe('SOUL.md');
    });

    test('does not expose file contents', () => {
      const dashboard = createDashboard();
      const req = mockReq();
      const res = mockRes();

      dashboard.getSecurity(req, res);

      const body = JSON.stringify(res._body);
      expect(body).not.toContain('A test agent');
      expect(body).not.toContain('Safe to Auto-Modify');
    });

    test('includes security alerts from audit', () => {
      const dashboard = createDashboard();
      const req = mockReq();
      const res = mockRes();

      dashboard.getSecurity(req, res);

      expect(res._body.alerts).toBeDefined();
      expect(Array.isArray(res._body.alerts)).toBe(true);
    });
  });

  describe('POST /api/security/acknowledge', () => {
    test('recomputes checksums after acknowledging', () => {
      fs.writeFileSync(path.join(projectRoot, 'SOUL.md'), '# Updated Agent\n\nNew version.');

      const dashboard = createDashboard();

      const checkReq = mockReq();
      const checkRes = mockRes();
      dashboard.getSecurity(checkReq, checkRes);
      expect(checkRes._body.integrityValid).toBe(false);

      const ackReq = mockReq();
      const ackRes = mockRes();
      dashboard.acknowledgeSecurity(ackReq, ackRes);
      expect(ackRes._body.success).toBe(true);

      const checkReq2 = mockReq();
      const checkRes2 = mockRes();
      dashboard.getSecurity(checkReq2, checkRes2);
      expect(checkRes2._body.integrityValid).toBe(true);
    });

    test('returns error when identity protection not configured', () => {
      const dashboard = createDashboard({ identityProtection: null });
      const req = mockReq();
      const res = mockRes();

      dashboard.acknowledgeSecurity(req, res);

      expect(res.statusCode).toBe(400);
    });
  });

  describe('Dashboard HTML', () => {
    test('serves the dashboard HTML file', () => {
      const dashboard = createDashboard();
      const req = mockReq();
      const res = mockRes();

      dashboard.serveDashboardHtml(req, res);

      expect(res._type).toBe('html');
      expect(res._body).toContain('<!DOCTYPE html>');
      expect(res._body).toContain('AppPilot Dashboard');
    });
  });

  describe('Mount', () => {
    test('registers all routes on the app', () => {
      const routes = [];
      const mockApp = {
        get(path, ...handlers) { routes.push({ method: 'GET', path }); },
        post(path, ...handlers) { routes.push({ method: 'POST', path }); },
      };

      const dashboard = createDashboard();
      dashboard.mount(mockApp);

      const paths = routes.map(r => `${r.method} ${r.path}`);
      expect(paths).toContain('GET /apppilot/dashboard');
      expect(paths).toContain('GET /apppilot/api/status');
      expect(paths).toContain('GET /apppilot/api/feed');
      expect(paths).toContain('GET /apppilot/api/errors');
      expect(paths).toContain('GET /apppilot/api/metrics');
      expect(paths).toContain('GET /apppilot/api/queue');
      expect(paths).toContain('POST /apppilot/api/queue/:id/approve');
      expect(paths).toContain('POST /apppilot/api/queue/:id/reject');
      expect(paths).toContain('GET /apppilot/api/security');
      expect(paths).toContain('POST /apppilot/api/security/acknowledge');
    });
  });

  describe('Edge cases', () => {
    test('handles missing memoryStore gracefully', () => {
      const dashboard = createDashboard({ memoryStore: null });
      const res = mockRes();

      dashboard.getStatus(mockReq(), res);
      expect(res._body.status).toBeDefined();

      const res2 = mockRes();
      dashboard.getFeed(mockReq(), res2);
      expect(res2._body.feed).toEqual([]);

      const res3 = mockRes();
      dashboard.getErrors(mockReq(), res3);
      expect(res3._body.errors).toEqual([]);
    });

    test('handles missing metricsCollector gracefully', () => {
      const dashboard = createDashboard({ metricsCollector: null });
      const res = mockRes();

      dashboard.getMetrics(mockReq(), res);
      expect(res._body.current).toEqual({});
    });

    test('handles empty queue directories', () => {
      const dashboard = createDashboard();
      const res = mockRes();

      dashboard.getQueue(mockReq(), res);
      expect(res._body.pending).toEqual([]);
      expect(res._body.approved).toEqual([]);
    });

    test('agent name defaults to AppPilot when SOUL.md has no title', () => {
      fs.writeFileSync(path.join(projectRoot, 'SOUL.md'), 'no heading here');

      const freshIdentity = new IdentityProtection(projectRoot, dataDir);
      freshIdentity.initialize();

      const dashboard = createDashboard({ identityProtection: freshIdentity });
      const res = mockRes();

      dashboard.getStatus(mockReq(), res);
      expect(res._body.agentName).toBe('AppPilot');
    });
  });
});
