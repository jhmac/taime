'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const { CodeEngine } = require('../src/code-engine');

function createTestProject() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'apppilot-engine-'));
  fs.mkdirSync(path.join(dir, 'src'), { recursive: true });
  fs.writeFileSync(path.join(dir, 'src', 'app.js'), 'const x = null;\nconsole.log(x);');
  fs.writeFileSync(path.join(dir, 'src', 'utils.js'), 'function add(a, b) { return a + b; }');
  fs.writeFileSync(path.join(dir, 'SOUL.md'), '# Soul');
  return dir;
}

function cleanDir(dir) {
  fs.rmSync(dir, { recursive: true, force: true });
}

describe('CodeEngine', () => {
  let projectDir;
  let engine;

  beforeEach(() => {
    projectDir = createTestProject();
    engine = new CodeEngine({
      projectRoot: projectDir,
      backupsDir: path.join(projectDir, 'apppilot', 'backups'),
      agentsContext: {
        content: '## Safe to Auto-Modify\n- src/**\n\n## Never Modify\n- config/secrets.js',
      },
    });
  });

  afterEach(() => {
    cleanDir(projectDir);
  });

  describe('backup', () => {
    test('creates backup of existing file', () => {
      const backupPath = engine.backup('src/app.js');
      expect(backupPath).not.toBeNull();
      expect(fs.existsSync(backupPath)).toBe(true);
      const backupContent = fs.readFileSync(backupPath, 'utf-8');
      expect(backupContent).toContain('const x = null;');
    });

    test('returns null for non-existent file', () => {
      const result = engine.backup('src/nonexistent.js');
      expect(result).toBeNull();
    });

    test('creates backups directory if missing', () => {
      const backupsDir = path.join(projectDir, 'apppilot', 'backups');
      expect(fs.existsSync(backupsDir)).toBe(false);
      engine.backup('src/app.js');
      expect(fs.existsSync(backupsDir)).toBe(true);
    });
  });

  describe('applyChange', () => {
    test('applies exact match replacement', () => {
      const result = engine.applyChange('src/app.js', 'const x = null;', 'const x = "hello";');
      expect(result.applied).toBe(true);
      expect(result.backupPath).toBeDefined();

      const content = fs.readFileSync(path.join(projectDir, 'src', 'app.js'), 'utf-8');
      expect(content).toContain('const x = "hello";');
      expect(content).toContain('console.log(x);');
    });

    test('creates backup before applying', () => {
      const result = engine.applyChange('src/app.js', 'const x = null;', 'const x = 42;');
      expect(result.backupPath).toBeDefined();
      expect(fs.existsSync(result.backupPath)).toBe(true);
    });

    test('rejects when old code not found', () => {
      const result = engine.applyChange('src/app.js', 'THIS DOES NOT EXIST', 'replacement');
      expect(result.applied).toBe(false);
      expect(result.reason).toContain('Old code not found');
    });

    test('rejects non-existent file', () => {
      const result = engine.applyChange('src/missing.js', 'old', 'new');
      expect(result.applied).toBe(false);
      expect(result.reason).toContain('File not found');
    });

    test('blocks identity file writes', () => {
      const result = engine.applyChange('SOUL.md', '# Soul', '# Hacked');
      expect(result.applied).toBe(false);
      expect(result.reason).toContain('Identity file');
    });

    test('blocks path traversal', () => {
      const result = engine.applyChange('../etc/passwd', 'old', 'new');
      expect(result.applied).toBe(false);
      expect(result.reason).toContain('traversal');
    });

    test('blocks files in protected paths', () => {
      fs.mkdirSync(path.join(projectDir, 'config'), { recursive: true });
      fs.writeFileSync(path.join(projectDir, 'config', 'secrets.js'), 'const key = "abc";');
      const result = engine.applyChange('config/secrets.js', 'const key = "abc";', 'const key = "xyz";');
      expect(result.applied).toBe(false);
      expect(result.reason).toContain('protected');
    });
  });

  describe('rollback', () => {
    test('restores file from backup', () => {
      const backupPath = engine.backup('src/app.js');
      fs.writeFileSync(path.join(projectDir, 'src', 'app.js'), 'CORRUPTED');

      const result = engine.rollback('src/app.js', backupPath);
      expect(result.restored).toBe(true);

      const content = fs.readFileSync(path.join(projectDir, 'src', 'app.js'), 'utf-8');
      expect(content).toContain('const x = null;');
    });

    test('fails when backup not found', () => {
      const result = engine.rollback('src/app.js', '/tmp/nonexistent-backup');
      expect(result.restored).toBe(false);
      expect(result.reason).toContain('Backup not found');
    });
  });

  describe('runTests', () => {
    test('rejects disallowed commands', () => {
      const result = engine.runTests('rm -rf /');
      expect(result.passed).toBe(false);
      expect(result.reason).toContain('not in whitelist');
    });

    test('accepts allowed commands', () => {
      const result = engine.runTests('npm test');
      expect(result).toBeDefined();
    });
  });

  describe('cleanupOldBackups', () => {
    test('removes old backups beyond keep count', () => {
      const backupsDir = path.join(projectDir, 'apppilot', 'backups');
      fs.mkdirSync(backupsDir, { recursive: true });

      for (let i = 0; i < 10; i++) {
        fs.writeFileSync(path.join(backupsDir, `file${String(i).padStart(3, '0')}.backup`), 'content');
      }

      engine.cleanupOldBackups(3);
      const remaining = fs.readdirSync(backupsDir);
      expect(remaining.length).toBe(3);
    });

    test('does nothing when under limit', () => {
      const backupsDir = path.join(projectDir, 'apppilot', 'backups');
      fs.mkdirSync(backupsDir, { recursive: true });
      fs.writeFileSync(path.join(backupsDir, 'file1.backup'), 'content');

      engine.cleanupOldBackups(50);
      expect(fs.readdirSync(backupsDir).length).toBe(1);
    });

    test('handles missing backups directory', () => {
      expect(() => engine.cleanupOldBackups(10)).not.toThrow();
    });
  });

  describe('_checkSafety', () => {
    test('blocks identity files', () => {
      const result = engine._checkSafety('SOUL.md');
      expect(result.safe).toBe(false);
    });

    test('allows safe paths', () => {
      const result = engine._checkSafety('src/app.js');
      expect(result.safe).toBe(true);
    });

    test('allows any path when no agents context', () => {
      const noCtxEngine = new CodeEngine({ projectRoot: projectDir });
      const result = noCtxEngine._checkSafety('random/file.js');
      expect(result.safe).toBe(true);
    });
  });
});
